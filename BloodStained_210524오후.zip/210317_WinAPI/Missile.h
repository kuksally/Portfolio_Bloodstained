#pragma once
#include "CameraObject.h"

class Enemy;
class Image;
class Missile : public CameraObject
{
public:
	enum TYPE { Normal, Skill_01, FollowTarget, End };

private:
	Image* fire;

	FPOINT pos;

	RECT shape;

	int size;

	int damage;

	int fireIndex;
	int fireStep;

	int frameX;
	int frameY;
	int maxFrame;

	float fireCount;

	float moveSpeed;
	float moveTime;

	float angle;
	float destAngle;

	bool isFired;

	TYPE missileType;

	Enemy* target;
	Enemy* owner;

public:
	HRESULT Init(Enemy* owner);
	void Release();		
	void Update();		
	void Render(HDC hdc);

	void MovingNormal();
	void MovingSkill_01();
	void MovingFollowTarget();

	inline void SetPos(FPOINT pos) { this->pos = pos; }
	inline FPOINT GetPos() { return this->pos; }

	void SetIsFired(bool isFired);
	inline bool GetIsFired() { return this->isFired; }

	inline void SetTarget(Enemy* target) { this->target = target; }

	inline void SetType(TYPE type) { this->missileType = type; }

	inline void SetAngle(float angle) { this->angle = angle; }

	inline void SetFireIndex(int fireIndex) { this->fireIndex = fireIndex; }

	inline int GetSize() { return this->size; }
};

