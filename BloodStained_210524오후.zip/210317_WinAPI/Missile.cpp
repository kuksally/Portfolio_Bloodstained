#include "Missile.h"
#include "Enemy.h"
#include "CommonFunction.h"
#include "Image.h"

HRESULT Missile::Init(Enemy* owner)
{
	this->owner = owner;

	fire = ImageManager::GetSingleton()->FindImage("Enemy3_Shoot");

	pos = {-100, -100};

	shape = { 0, 0, 0, 0 };

	size = 40;

	damage = 1;

	fireStep = 0;

	frameX = 0;
	frameY = 1;
	maxFrame = 5;

	fireCount = 0.0f;

	moveSpeed = 500.0f;
	moveTime = 10.0f;

	angle = 0.0f;
	destAngle = 0.0f;

	isFired = false;

	missileType = TYPE::Normal;

	target = nullptr;

    return S_OK;
}

void Missile::Release()
{

}

void Missile::Update()
{
	worldPos = pos;

	float elapsedTime = TimerManager::GetSingleton()->GetElapsedTime();
	// ��ġ �̵�
	if (isFired)
	{
		switch (missileType)
		{
		case TYPE::Normal:
			MovingNormal();
			break;
		case TYPE::Skill_01:
			MovingSkill_01();
			break;
		case TYPE::FollowTarget:
			MovingFollowTarget();
			break;
		}
		pos.x += cosf(angle) * moveSpeed * elapsedTime;
		pos.y -= sinf(angle) * moveSpeed * elapsedTime;
		if (pos.x < 0 || pos.y < 0 || pos.x > WINSIZE_X || pos.y > WINSIZE_Y)
		{
			isFired = false;
			fireStep = 0;
		}
	}

	shape.left = pos.x - size / 2;
	shape.top = pos.y - size / 2;
	shape.right = pos.x + size / 2;
	shape.bottom = pos.y + size / 2;

	fireCount++;
	if (fireCount == 20.0f)
	{
		frameX++;
		if (frameX >= maxFrame)
		{
			frameX = 0;
		}

		fireCount = 0.0f;
	}

	CameraObject::UpdatePos();
}

void Missile::Render(HDC hdc)
{
	if (isFired)
	{
		fire->FrameRender(hdc, scPos.x, scPos.y, frameX, frameY, true);
		//Ellipse(hdc, shape.left, shape.top, shape.right, shape.bottom);
	}
}

void Missile::MovingNormal()
{
	float elapsedTime = TimerManager::GetSingleton()->GetElapsedTime();
	pos.x += cosf(angle) * moveSpeed * elapsedTime / moveTime;
	pos.y -= sinf(angle) * moveSpeed * elapsedTime / moveTime;
}

void Missile::MovingSkill_01()
{
	if (fireStep == 0 && pos.y < 300.0f)
	{
		angle = fireIndex * 3.14f * 2.0f / 36.0f;
		fireStep++;
	}

	pos.x += cosf(angle) * moveSpeed;
	pos.y -= sinf(angle) * moveSpeed;
}

void Missile::MovingFollowTarget()
{
	if (target)
	{
		destAngle = GetAngle(pos, target->GetPos());
		float ratio = (destAngle - angle) / 50.0f;

		if (-0.01f < ratio && ratio < 0.01f)
		{
			angle = destAngle;
		}
		else
		{
			angle += ratio;
		}
	}

	pos.x += cosf(angle) * moveSpeed;
	pos.y -= sinf(angle) * moveSpeed;
}

void Missile::SetIsFired(bool isFired)
{
	this->isFired = isFired;
	pos.x = owner->GetPos().x;
	pos.y = owner->GetPos().y;
}