#include "GameData.h"

HRESULT GameData::Init()
{
    playerLife = 1;
    playerHp = 12;

    return S_OK;
}
