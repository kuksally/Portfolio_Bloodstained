#include "Boss.h"

HRESULT Boss::Init(int PosX, int PosY)
{
	return S_OK;
}

void Boss::Release()
{
}

void Boss::Update()
{
}

void Boss::Render(HDC hdc)
{
}

void Boss::Attack()
{
}