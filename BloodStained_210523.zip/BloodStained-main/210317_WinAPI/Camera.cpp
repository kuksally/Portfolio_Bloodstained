#include "Camera.h"

void Camera::SetCameraPos(FPOINT cameraPos)
{
	// ī�޶� ����ó��
	if (cameraPos.x < WINSIZE_X / 2) { cameraPos.x = WINSIZE_X / 2; }
	//if (cameraPos.x > maxPos.x) { cameraPos.x = maxPos.x; }
	//if (cameraPos.y < 0) { cameraPos.y = 0; }
	if (cameraPos.y > maxPos.y) { cameraPos.y = maxPos.y; }

	this->cameraPos.x = cameraPos.x;
	this->cameraPos.y = cameraPos.y;
}

FPOINT Camera::GetCameraPos()
{
	return this->cameraPos;
}
