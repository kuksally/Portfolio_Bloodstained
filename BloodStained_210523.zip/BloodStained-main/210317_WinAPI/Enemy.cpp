#include "Enemy.h"

HRESULT Enemy::Init(int posX, int posY)
{
	return S_OK;
}

void Enemy::Release()
{
}

void Enemy::Update()
{
}

void Enemy::Render(HDC hdc)
{
}

void Enemy::Move()
{
}
