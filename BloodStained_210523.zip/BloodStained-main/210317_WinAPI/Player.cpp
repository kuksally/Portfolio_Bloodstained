#include "Player.h"
#include "Image.h"
#include "CommonFunction.h"
#include "Camera.h"

PIXEL_TILE_INFO Player::pixelTileInfo[TILE_X * TILE_Y];

HRESULT Player::Init()
{
	pixelCollisionImage = ImageManager::GetSingleton()->FindImage("PixelTile");

	// ���� ��ǥ
	//pos.x = /*WINSIZE_X / 2*/ 50;
	//pos.y = WINSIZE_Y - 180 - 60;

	// ���� ��ǥ
	pos.x = 50;
	pos.y = 400/*480*/;

	size = 45;
	attackSize = 20;

	frameX = 0;
	frameY = 1;
	maxFrame = 6;

	playerLives = 1;
	playerHp = 6;
	playerAttack = 10;

	moveSpeed = 250.0f;
	stairsSpeed = 40.0f;	// ��� �̵� �ӵ�

	time = 0.0f;
	maxTime = 20.0f;
	jumpPower = 105;
	gravity = 9.81f;

	isAlive = true;
	isDying = false;
	isLeft = false;		// ����
	isAttack = false;
	isJump = false;
	isStairs = false;

	state = STATE::R_INTRO;

	return S_OK;
}

void Player::Release()
{
}

void Player::Update()
{
	worldPos.x = pos.x;
	worldPos.y = pos.y;

	if (KeyManager::GetSingleton()->IsOnceKeyDown('H'))
	{
		playerHp = playerHp - 1;
	}
	if (playerHp <= 0)
	{
		playerLives = playerLives - 1;

		if (playerLives != 0)
		{
			playerHp = 12;
		}

		if (playerLives == 0)
		{
			isAlive = false;
			isDying = true;
		}
	}

	if (isAlive && KeyManager::GetSingleton()->IsOnceKeyDown(VK_RETURN))
	{
		isAlive = false;
		isDying = true;
	}

	if (isDying)
	{
		OnDead();
	}
	else
	{
		Move();
		Animation();
	}

	time++;
	if (time >= maxTime)
	{
		frameX++;
		if (frameX >= maxFrame)
		{
			if (state == STATE::R_INTRO)
			{
				state = STATE::R_IDLE;
			}

			if (state == STATE::R_ATTACK_BASIC)
			{
				state = STATE::R_IDLE;
			}
			else if (state == STATE::L_ATTACK_BASIC)
			{
				state = STATE::L_IDLE;
			}

			isAttack = false;

			frameX = 0;
		}

		time = 0;
	}

	rcPlayer = GetRectToCenter(scPos.x, scPos.y + 20, size, size);

	if (frameX == 3 && isAttack == true && isLeft == false)
	{
		rcAttack = GetRectToCenter(scPos.x + 50, scPos.y + 10, attackSize, attackSize);
	}
	else if (frameX == 3 && isAttack == true &&isLeft == true)
	{
		rcAttack = GetRectToCenter(scPos.x - 50, scPos.y + 10, attackSize, attackSize);
	}
	else
	{
		rcAttack = GetRectToCenter(scPos.x - 100000, scPos.y + 100000, attackSize, attackSize);
	}

	PixelCollision();

	Camera::GetSingleton()->SetCameraPos(pos);	// ������ ã�� ��

	UpdatePos();
}

void Player::Render(HDC hdc)
{
	RenderRectToCenter(hdc, scPos.x, scPos.y + 20, size, size);

	if (frameX == 3 && isAttack == true && isLeft == false)
	{
		RenderRectToCenter(hdc, scPos.x + 50, scPos.y + 10, attackSize, attackSize);
	}
	else if (frameX == 3 && isAttack == true && isLeft == true)
	{
		RenderRectToCenter(hdc, scPos.x - 50, scPos.y + 10, attackSize, attackSize);
	}

	if (playerImage)
	{
		playerImage->FrameRender(hdc, scPos.x, scPos.y, frameX, frameY, true);
	}

	//for (int i = 0; i < TILE_X * TILE_Y; i++)
	//{
	//	pixelCollisionImage->FrameRender(hdc,
	//		pixelTileInfo[i].rcTile.left - Camera::GetSingleton()->GetCameraPos().x,
	//		pixelTileInfo[i].rcTile.top,
	//		pixelTileInfo[i].frameX,
	//		pixelTileInfo[i].frameY);
	//}
}

void Player::OnDead()
{
	//if (image)
	//{
	//	BLENDFUNCTION* blendFunc = image->GetBlendFunc();

	//	if (blendFunc->SourceConstantAlpha > 120)
	//	{
	//		blendFunc->SourceConstantAlpha--;
	//	}
	//	else
	//	{
	//		isDying = false;
	//		isAlive = false;
	//	}
	//}
}

void Player::Move()
{
	// �÷��̾� ����
	if (pos.y < WINSIZE_Y )
	{
		pos.y += gravity * TimerManager::GetSingleton()->GetElapsedTime();
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LEFT))
	{
		isLeft = true;
		state = STATE::L_WALK;

	}
	else if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LEFT))
	{
		state = STATE::L_IDLE;
	}

	if (state == STATE::L_WALK)
	{
		pos.x -= moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();
	}

	if (isLeft == true && state == STATE::L_WALK/* || state == STATE::L_STAIRS_UP*/)
	{
		//pos.x -= moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();

		if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
		{
			isStairs = true;
			state = STATE::L_STAIRS_UP;
		}
		else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
		{
			isStairs = true;
			state = STATE::L_STAIRS_DOWN;
		}
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_RIGHT))
	{
		isLeft = false;
		state = STATE::R_WALK;
	}
	else if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_RIGHT))
	{
		state = STATE::R_IDLE;
	}

	//if (state == STATE::R_WALK)
	//{
	//	pos.x += moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();
	//}

	if (isLeft == false && state == STATE::R_WALK || state == STATE::R_STAIRS_UP)
	{
		pos.x += moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();

		if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP))
		{
			isStairs = true;
			state = STATE::R_STAIRS_UP;
		}
		//if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_UP))
		//{
		//	isStairs = false;
		//	//state = STATE::R_STAIRS_UP;
		//}
		else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
		{
			isStairs = true;
			state = STATE::R_STAIRS_DOWN;
		}
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_DOWN))
	{
		if (isLeft == true)
		{
			state = STATE::L_CROUCH;
		}
		else
		{
			state = STATE::R_CROUCH;
		}
	}
	else if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_DOWN))
	{
		if (isLeft == true)
		{
			state = STATE::L_IDLE;
		}
		else
		{
			state = STATE::R_IDLE;
		}
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_CONTROL))
	{
		isAttack = true;

		if (isLeft == true)
		{
			state = STATE::L_ATTACK_BASIC;
		}
		else
		{
			state = STATE::R_ATTACK_BASIC;
		}
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_MENU))
	{
		if (isLeft == true)
		{
			state = STATE::L_JUMP;
		}
		else
		{
			state = STATE::R_JUMP;
		}

	}
	else if (state == STATE::L_JUMP || state == STATE::R_JUMP)
	{
		Jump();
	}
}

void Player::Jump()
{
}

void Player::Animation()
{
	switch (state)
	{
	case STATE::L_INTRO:
		playerImage = ImageManager::GetSingleton()->FindImage("Intro");
		frameY = 0;
		maxFrame = 6;
		maxTime = 20.0f;
		break;
	case STATE::L_IDLE:
		playerImage = ImageManager::GetSingleton()->FindImage("Idle");
		frameY = 0;
		maxFrame = 1;
		maxTime = 0.0f;
		break;
	case STATE::L_WALK:
		playerImage = ImageManager::GetSingleton()->FindImage("Walk");
		frameY = 0;
		maxFrame = 4;
		maxTime = 15.0f;
		break;
	case STATE::L_CROUCH:
		playerImage = ImageManager::GetSingleton()->FindImage("Crouch");
		frameY = 0;
		maxFrame = 1;
		maxTime = 0.0f;
		break;
	case STATE::L_JUMP:
		playerImage = ImageManager::GetSingleton()->FindImage("Jump");
		frameY = 0;
		maxFrame = 2;
		maxTime = 20.0f;
		break;
	case STATE::L_STAIRS_UP:
		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
		frameY = 0;
		maxFrame = 2;
		maxTime = 15.0f;
		break;
	case STATE::L_STAIRS_DOWN:
		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
		frameY = 2;
		maxFrame = 2;
		maxTime = 15.0f;
		break;
	case STATE::L_ATTACK_BASIC:
		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
		frameY = 0;
		maxFrame = 4;
		maxTime = 5.0f;
		break;
	case STATE::L_ATTACK_CROUCH:
		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
		frameY = 2;
		maxFrame = 4;
		maxTime = 10.0f;
		break;
	case STATE::L_ATTACK_JUMP:
		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
		frameY = 4;
		maxFrame = 4;
		maxTime = 10.0f;
		break;
	case STATE::R_INTRO:
		playerImage = ImageManager::GetSingleton()->FindImage("Intro");
		frameY = 1;
		maxFrame = 6;
		maxTime = 20.0f;
		break;
	case STATE::R_IDLE:
		playerImage = ImageManager::GetSingleton()->FindImage("Idle");
		frameY = 1;
		maxFrame = 1;
		maxTime = 0.0f;
		break;
	case STATE::R_WALK:
		playerImage = ImageManager::GetSingleton()->FindImage("Walk");
		frameY = 1;
		maxFrame = 4;
		maxTime = 15.0f;
		break;
	case STATE::R_CROUCH:
		playerImage = ImageManager::GetSingleton()->FindImage("Crouch");
		frameY = 1;
		maxFrame = 1;
		maxTime = 0.0f;
		break;
	case STATE::R_JUMP:
		playerImage = ImageManager::GetSingleton()->FindImage("Jump");
		frameY = 1;
		maxFrame = 2;
		maxTime = 20.0f;
		break;
	case STATE::R_STAIRS_UP:
		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
		frameY = 1;
		maxFrame = 2;
		maxTime = 15.0f;
		break;
	case STATE::R_STAIRS_DOWN:
		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
		frameY = 3;
		maxFrame = 2;
		maxTime = 15.0f;
		break;
	case STATE::R_ATTACK_BASIC:
		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
		frameY = 1;
		maxFrame = 4;
		maxTime = 5.0f;
		break;
	case STATE::R_ATTACK_CROUCH:
		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
		frameY = 3;
		maxFrame = 4;
		maxTime = 10.0f;
		break;
	case STATE::R_ATTACK_JUMP:
		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
		frameY = 5;
		maxFrame = 4;
		maxTime = 10.0f;
		break;
	case STATE::END:
		break;
	}
}

//void Player::ChangeState(STATE nextState)
//{
//	this->state = nextState;
//
//	switch (state)
//	{
//	case STATE::L_INTRO:
//		playerImage = ImageManager::GetSingleton()->FindImage("Intro");
//		frameY = 0;
//		maxFrame = 6;
//		maxTime = 20.0f;
//		break;
//	case STATE::L_IDLE:
//		playerImage = ImageManager::GetSingleton()->FindImage("Idle");
//		frameY = 0;
//		maxFrame = 1;
//		maxTime = 0.0f;
//		break;
//	case STATE::L_WALK:
//		playerImage = ImageManager::GetSingleton()->FindImage("Walk");
//		frameY = 0;
//		maxFrame = 4;
//		maxTime = 15.0f;
//		break;
//	case STATE::L_CROUCH:
//		playerImage = ImageManager::GetSingleton()->FindImage("Crouch");
//		frameY = 0;
//		maxFrame = 1;
//		maxTime = 0.0f;
//		break;
//	case STATE::L_JUMP:
//		playerImage = ImageManager::GetSingleton()->FindImage("Jump");
//		frameY = 0;
//		maxFrame = 2;
//		maxTime = 20.0f;
//		break;
//	case STATE::L_STAIRS_UP:
//		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
//		frameY = 0;
//		maxFrame = 2;
//		maxTime = 15.0f;
//		break;
//	case STATE::L_STAIRS_DOWN:
//		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
//		frameY = 2;
//		maxFrame = 2;
//		maxTime = 15.0f;
//		break;
//	case STATE::L_ATTACK_BASIC:
//		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
//		frameY = 0;
//		maxFrame = 4;
//		maxTime = 5.0f;
//		break;
//	case STATE::L_ATTACK_CROUCH:
//		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
//		frameY = 2;
//		maxFrame = 4;
//		maxTime = 10.0f;
//		break;
//	case STATE::L_ATTACK_JUMP:
//		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
//		frameY = 4;
//		maxFrame = 4;
//		maxTime = 10.0f;
//		break;
//	case STATE::R_INTRO:
//		playerImage = ImageManager::GetSingleton()->FindImage("Intro");
//		frameY = 1;
//		maxFrame = 6;
//		maxTime = 20.0f;
//		break;
//	case STATE::R_IDLE:
//		playerImage = ImageManager::GetSingleton()->FindImage("Idle");
//		frameY = 1;
//		maxFrame = 1;
//		maxTime = 0.0f;
//		break;
//	case STATE::R_WALK:
//		playerImage = ImageManager::GetSingleton()->FindImage("Walk");
//		frameY = 1;
//		maxFrame = 4;
//		maxTime = 15.0f;
//		break;
//	case STATE::R_CROUCH:
//		playerImage = ImageManager::GetSingleton()->FindImage("Crouch");
//		frameY = 1;
//		maxFrame = 1;
//		maxTime = 0.0f;
//		break;
//	case STATE::R_JUMP:
//		playerImage = ImageManager::GetSingleton()->FindImage("Jump");
//		frameY = 1;
//		maxFrame = 2;
//		maxTime = 20.0f;
//		break;
//	case STATE::R_STAIRS_UP:
//		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
//		frameY = 1;
//		maxFrame = 2;
//		maxTime = 15.0f;
//		break;
//	case STATE::R_STAIRS_DOWN:
//		playerImage = ImageManager::GetSingleton()->FindImage("Stairs");
//		frameY = 3;
//		maxFrame = 2;
//		maxTime = 15.0f;
//		break;
//	case STATE::R_ATTACK_BASIC:
//		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
//		frameY = 1;
//		maxFrame = 4;
//		maxTime = 5.0f;
//		break;
//	case STATE::R_ATTACK_CROUCH:
//		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
//		frameY = 3;
//		maxFrame = 4;
//		maxTime = 10.0f;
//		break;
//	case STATE::R_ATTACK_JUMP:
//		playerImage = ImageManager::GetSingleton()->FindImage("Attack");
//		frameY = 5;
//		maxFrame = 4;
//		maxTime = 10.0f;
//		break;
//	case STATE::END:
//		break;
//	}
//}

void Player::PixelCollision()
{
	if (playerImage)
	{
		// �ȼ� �浹 Ȯ��
		COLORREF color;
		int R, G, B;
		float currPosY = pos.y + playerImage->GetFrameHeight();
		float currPosX = pos.x + playerImage->GetFrameWidth();

		// Y��
		for (int i = currPosY - 3; i < currPosY + 3; i++)
		{
			color = GetPixel(pixelCollisionImage->GetMemDC(), pos.x, i);

			R = GetRValue(color);
			G = GetGValue(color);
			B = GetBValue(color);

			// �ٴ�, �� Ÿ��
			if (R == 255 && G == 0 && B == 0)  // �������� �ʰ� ó��
			{
				// ��ġ ����
				pos.y = i - playerImage->GetFrameHeight();
				break;
			}
			
			// ���
			if (R == 0 && G == 0 && B == 255 && isStairs == true)
			{
				pos.y = i - playerImage->GetFrameHeight();
				break;
			}
		}

		// X��
		for (int i = currPosX - 3; i < currPosX + 3; i++)
		{
			color = GetPixel(pixelCollisionImage->GetMemDC(), i, pos.y);

			R = GetRValue(color);
			G = GetGValue(color);
			B = GetBValue(color);

			if (R == 0 && G == 255 && B == 0)  // �������� �ʰ� ó��
			{
				// ���̶� �ȼ� �浹 ���� ��

				break;
			}
		}
	}
}

void Player::UpdatePos()
{
	scPos.x = worldPos.x + (WINSIZE_X / 2) - Camera::GetSingleton()->GetCameraPos().x;
	scPos.y = worldPos.y + (WINSIZE_Y / 2) - Camera::GetSingleton()->GetCameraPos().y;
}