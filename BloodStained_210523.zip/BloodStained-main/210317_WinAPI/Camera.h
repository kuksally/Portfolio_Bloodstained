#pragma once
#include "config.h"
#include "Singleton.h"

class Camera : public Singleton<Camera>
{
private:
	FPOINT cameraPos;
	FPOINT maxPos;

public:
	void SetMapMaxPos(FPOINT maxPos) { this->maxPos = maxPos; };

	void SetCameraPos(FPOINT cameraPos);
	FPOINT GetCameraPos();
};