#pragma once
#include "GameNode.h"

class EnemyManager;
class Enemy;
class Player;
class CheckCollision : public GameNode
{
private:
	bool beShot;
	bool isCollision;

	Player* player;

	EnemyManager* enemyMgr;

public:
	virtual HRESULT Init();
	virtual void Release();			
	virtual void Update();			
	virtual void Render(HDC hdc);	

	void CollisionCheck(Player* player, EnemyManager* enemyMgr);
	
	virtual ~CheckCollision() {};
};