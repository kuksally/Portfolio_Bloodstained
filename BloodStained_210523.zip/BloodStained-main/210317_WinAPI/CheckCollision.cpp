#include "CheckCollision.h"
#include "CommonFunction.h"
#include "Player.h"
#include "Enemy.h"
#include "EnemyManager.h"

HRESULT CheckCollision::Init()
{
	beShot = false;

	isCollision = false;

	return S_OK;
}

void CheckCollision::Release()
{
}

void CheckCollision::Update()
{
}

void CheckCollision::Render(HDC hdc)
{
}

void CheckCollision::CollisionCheck(Player* player, EnemyManager* enemyMgr)
{
	if (player != nullptr && enemyMgr != nullptr)
	{
		for (int i = 0; i < enemyMgr->GetEnemys().size(); i++)
		{
			// �÷��̾�� �� ������ ��
			if (RectInRect(player->GetPlayerRect(), enemyMgr->GetEnemys()[0]->GetEnemyRect()) && isCollision == true)
			{
				isCollision = false;

				//player->SetPlayerHp(player->GetPlayerHp() - 1);

				player->SetPlayerHp(player->GetPlayerHp() - enemyMgr->GetEnemys()[0]->GetEnemyAttack());
			}
			else if (!(RectInRect(player->GetPlayerRect(), enemyMgr->GetEnemys()[0]->GetEnemyRect())))
			{
				isCollision = true;
			}

			// �÷��̾ �������� ��
			if (RectInRect(enemyMgr->GetEnemys()[0]->GetEnemyRect(),player->GetAttackRect()) && player->GetIsAttack())
			{
				player->SetIsAttack(false);

				enemyMgr->GetEnemys()[0]->SetEnemyHp(enemyMgr->GetEnemys()[0]->GetEnemyHp() - player->GetPlayerAttack());
			}
			else if (!(RectInRect(player->GetAttackRect(), enemyMgr->GetEnemys()[0]->GetEnemyRect())))
			{
				player->GetIsAttack();
			}
		}
	}
}