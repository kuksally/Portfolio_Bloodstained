#include "GameData.h"

HRESULT GameData::Init()
{
    playerLife = 3;
    playerHp = 12;

    return S_OK;
}
