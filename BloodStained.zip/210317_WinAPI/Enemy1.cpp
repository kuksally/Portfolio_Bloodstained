#include "Enemy1.h"
#include "CommonFunction.h"
#include "Image.h"
#include "Camera.h"

HRESULT Enemy1::Init(int posX, int posY)
{
    enemy = ImageManager::GetSingleton()->FindImage("Enemy1");

    enemyMove = ImageManager::GetSingleton()->FindImage("Enemy1_Move");

    pos.x = posX;
    pos.y = posY;

    size = 50;

    enemyHp = 20;
    enemyAttack = 1;

    frameX = 0;
    frameY = 1;
    maxFrame = 7;
    updateCount = 0;

    moveSpeed = 150.0f;

    isAlive = true;
    isLeft = true;
    isMove = false;

    return S_OK;
}

void Enemy1::Release()
{
}

void Enemy1::Update()
{
    worldPos.x = pos.x;
    worldPos.y = pos.y;
   
    if (isAlive)
    {
        // �ִϸ��̼� ������
        updateCount++;
        if (updateCount == 20)
        {
            frameX++;
            if (frameX >= maxFrame)
            {
                frameX = 0;
            }

            updateCount = 0;
        }

        rcEnemy = GetRectToCenter(scPos.x, scPos.y, size, size);
    }

    if (enemyHp == 0)
    {
        isAlive = false;
        rcEnemy = GetRectToCenter(scPos.x - 100, scPos.y -100, size, size);
    }

    Move();

    CameraObject::UpdatePos();
}

void Enemy1::Render(HDC hdc)
{
    if (isAlive)
    {
        if (enemy)
        {
            RenderRectToCenter(hdc, scPos.x, scPos.y, size, size);

            enemy->FrameRender(hdc, scPos.x, scPos.y, frameX, frameY, true); 
        }

        if (isMove == true);
        {
            if (enemyMove)
            {
                enemyMove->FrameRender(hdc, pos.x, pos.y, frameX, frameY, true);
            }
        }
    }
}

void Enemy1::Move()
{
    if (KeyManager::GetSingleton()->IsStayKeyDown('J'))
    {
        isMove = true;
        frameY = 1;
        maxFrame = 2;
        pos.x -= moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();
    }
    
    if(KeyManager::GetSingleton()->IsStayKeyDown('L'))
    {
        isMove = true;
        frameY = 0;
        maxFrame = 2;
        pos.x += moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();
    }
}