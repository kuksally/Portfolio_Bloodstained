#include "CameraObject.h"
#include "Camera.h"

void CameraObject::UpdatePos()
{
	// �÷��̾� �̿� ����
	scPos.x = worldPos.x - Camera::GetSingleton()->GetCameraPos().x;
	scPos.y = worldPos.y - Camera::GetSingleton()->GetCameraPos().y;
}