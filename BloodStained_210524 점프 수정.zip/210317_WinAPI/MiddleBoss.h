#pragma once
class MiddleBoss
{
};

