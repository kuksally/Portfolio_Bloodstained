#include "CheckCollision.h"
#include "CommonFunction.h"
#include "Player.h"
#include "Enemy.h"
#include "EnemyManager.h"

HRESULT CheckCollision::Init()
{
	//beShot = false;

	//isCollision = false;

	return S_OK;
}

void CheckCollision::Release()
{
}

void CheckCollision::Update()
{
}

void CheckCollision::Render(HDC hdc)
{
}

void CheckCollision::CollisionCheck(Player* player, EnemyManager* enemyMgr)
{
	if (player != nullptr && enemyMgr != nullptr)
	{
		for (int i = 0; i < enemyMgr->GetEnemys().size(); i++)
		{
			// �÷��̾�� �� ������ ��
			if (RectInRect(player->GetPlayerRect(), enemyMgr->GetEnemys()[i]->GetEnemyRect()) && player->GetIsCollision() == false)
			{
				player->SetIsCollision(true);

				player->SetPlayerHp(player->GetPlayerHp() - enemyMgr->GetEnemys()[i]->GetEnemyAttack());

			}

			// �÷��̾ �������� ��
			if (RectInRect(player->GetAttackRect(), enemyMgr->GetEnemys()[i]->GetEnemyRect()) && player->GetIsAttack() == true)
			{
				player->SetIsAttack(false);

				enemyMgr->GetEnemys()[i]->SetEnemyHp(enemyMgr->GetEnemys()[i]->GetEnemyHp() - player->GetPlayerAttack());
			}
			//else if (!(RectInRect(player->GetAttackRect(), enemyMgr->GetEnemys()[i]->GetEnemyRect())))
			//{
			//	player->GetIsAttack();
			//}
		}
	}
}