#include "ImageManager.h"
#include "Image.h"

HRESULT ImageManager::Init()
{
#pragma region UI
    // title_UI
    GetSingleton()->AddImage("TitleBackGround", "Image/UI/Title&Select/TitleBackGround.bmp", 1080, 720);
    GetSingleton()->AddImage("TitleLogo", "Image/UI/Title&Select/TitleLogo.bmp", 1000, 1235, 1, 4, true, RGB(0, 0, 0));
    GetSingleton()->AddImage("TitlePressButton", "Image/UI/Title&Select/PressButton.bmp", 378, 54, 1, 2);
    // select_UI
    GetSingleton()->AddImage("SelectList", "Image/UI/Title&Select/SelectList.bmp", 270, 324, 1, 6, true, RGB(0, 0, 0));
    GetSingleton()->AddImage("SelectArrow", "Image/UI/Title&Select/SelectArrow.bmp", 460, 40, true, RGB(0, 0, 0));
    // battle_PlayerUI
    GetSingleton()->AddImage("PlayerInit", "Image/UI/PlayerUI/PlayerInit.bmp", 126, 33, true, RGB(0, 0, 0));
    GetSingleton()->AddImage("PlayerLivesCount1","Image/UI/PlayerUI/LivesCount1.bmp", 32, 18, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("PlayerLivesCount2","Image/UI/PlayerUI/LivesCount2.bmp", 32, 18, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("PlayerLivesCount3","Image/UI/PlayerUI/LivesCount3.bmp", 32, 18, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("PlayerHpCount", "Image/UI/PlayerUI/HpCount.bmp", 8, 10, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("PlayerPicture", "Image/UI/PlayerUI/Picture.bmp", 53, 68, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("PlayerWeapon", "Image/UI/PlayerUI/Weapon.bmp", 24, 24);
    GetSingleton()->AddImage("PlayerScore", "Image/UI/PlayerUI/Score.bmp", 101, 18, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("PlayerScorePoint", "Image/UI/PlayerUI/ScorePoint.bmp", 128, 18, true, RGB(255, 0, 255));
    // gameOver_UI
    GetSingleton()->AddImage("GameOverBackGround", "Image/UI/GameOver/GameOver.bmp", 1080, 720);
    GetSingleton()->AddImage("GameOverList", "Image/UI/GameOver/GameOverList.bmp", 260, 432, 1, 6, true, RGB(0, 0, 0));
    GetSingleton()->AddImage("GameOverArrow", "Image/UI/GameOver/GameOverArrow.bmp", 356, 45, true, RGB(255, 0, 255));
#pragma endregion

#pragma region Tile + BackGround + Button
    // sampleTile
    GetSingleton()->AddImage("SampleTile", "Image/Tile/SampleTile.bmp", 160, 200, SAMPLE_TILE_X, SAMPLE_TILE_Y, true, RGB(255, 0, 255));
    // pixelTile
    GetSingleton()->AddImage("PixelTile", "Image/Tile/PixelTile.bmp", 160, 200, SAMPLE_TILE_X, SAMPLE_TILE_Y, true, RGB(255, 0, 255));
    // background
    GetSingleton()->AddImage("Black", "Image/BackGround/Black.bmp", 1080, 720);
    GetSingleton()->AddImage("Moon", "Image/BackGround/Moon.bmp", 1080, 600);
    GetSingleton()->AddImage("BackGround1", "Image/BackGround/BackGround1.bmp", 2000, 600, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("BackGround2", "Image/BackGround/BackGround2.bmp", 2000, 600, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("BackGround3", "Image/BackGround/BackGround3.bmp", 2000, 600, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("BackGround4", "Image/BackGround/BackGround4.bmp", 4000, 600, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("BackGround5", "Image/BackGround/BackGround5.bmp", 2000, 600, true, RGB(255, 0, 255));
    // UI_Button
    GetSingleton()->AddImage("SaveButton", "Image/Button/SaveButton.bmp", 100, 267, 1, 2);
    GetSingleton()->AddImage("LoadButton", "Image/Button/LoadButton.bmp", 100, 267, 1, 2);
#pragma endregion

#pragma region Player : Move, Attack
    GetSingleton()->AddImage("Intro", "Image/Player/Intro.bmp", 720, 240, 6, 2, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("Idle", "Image/Player/Idle.bmp", 120, 240, 1, 2, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("Walk", "Image/Player/Walk.bmp", 480, 240, 4, 2, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("Crouch", "Image/Player/Crouch.bmp", 120, 240, 1, 2, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("Jump", "Image/Player/Jump.bmp", 240, 240, 2, 2, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("Stairs", "Image/Player/Stairs.bmp", 240, 480, 2, 4, true, RGB(255, 0, 255));
    GetSingleton()->AddImage("Attack", "Image/Player/Attack.bmp", 480, 720, 4, 6, true, RGB(255, 0, 255));
#pragma endregion

#pragma region Enemy
    // enemy1
    GetSingleton()->AddImage("Enemy1", "Image/Enemy/Enemy1.bmp", 378, 132, 7, 2, true, RGB(0, 0, 255));
    GetSingleton()->AddImage("Enemy1_Move", "Image/Enemy/Enemy1_Move.bmp", 108, 132, 2, 2, true, RGB(0, 0, 255));
    // enemy2
    GetSingleton()->AddImage("Enemy2", "Image/Enemy/Enemy2.bmp", 217 * 2, 32 * 2, 7, 2, true, RGB(0, 0, 255));
    GetSingleton()->AddImage("Enemy2_Move", "Image/Enemy/Enemy2_Move.bmp", 62 * 2, 32 * 2, 2, 2, true, RGB(0, 0, 255));
    // enemy3
    GetSingleton()->AddImage("Enemy3", "Image/Enemy/Enemy3.bmp", 80 * 2, 64 * 2, 5, 2, true, RGB(0, 0, 255));
    GetSingleton()->AddImage("Enemy3_Shoot", "Image/Enemy/Enemy3_Shoot.bmp", 80 * 2, 32 * 2, 5, 2, true, RGB(0, 0, 255));
#pragma endregion

#pragma region Boss
    // middle
    GetSingleton()->AddImage("Middle_Boss", "Image/Boss/Middle_Boss.bmp", 924, 71, 11, 1, true, RGB(0, 0, 255));
#pragma endregion


    return S_OK;
}

void ImageManager::Release()
{
    // ��� �̹����� ���� �޸� ������ �̷�� ����.
    map<string, Image*>::iterator it;
    for (it = mImageDatas.begin(); it != mImageDatas.end(); it++)
    {
        if ((it->second))
        {
            (it->second)->Release();
            delete (it->second);
            (it->second) = nullptr;
        }
    }
    mImageDatas.clear();

    ReleaseSingleton();
}

Image* ImageManager::AddImage(string key, const char* fileName, int width, int height, bool isTransparent, COLORREF transColor)
{
    Image* image = nullptr;

    // �ʿ� Ű�� �ش��ϴ� �����Ͱ� ������ �߰��������� ����
    image = FindImage(key);
    if (image)
    {
        return image;
    }

    // ������ ���� �� �ʿ� �߰�
    image = new Image();
    if (FAILED(image->Init(fileName, width, height, isTransparent, transColor)))
    {
        image->Release();
        delete image;

        return nullptr;
    }

    mImageDatas.insert(make_pair(key, image));
    return image;
}

Image* ImageManager::AddImage(string key, const char* fileName, int width, int height, int maxFrameX, int maxFrameY, bool isTransparent, COLORREF transColor)
{
    Image* image = nullptr;

    // �ʿ� Ű�� �ش��ϴ� �����Ͱ� ������ �߰��������� ����
    image = FindImage(key);
    if (image)
    {
        return image;
    }

    // ������ ���� �� �ʿ� �߰�
    image = new Image();
    if (FAILED(image->Init(fileName, width, height,
        maxFrameX, maxFrameY, isTransparent, transColor)))
    {
        image->Release();
        delete image;

        return nullptr;
    }

    mImageDatas.insert(make_pair(key, image));
    return image;
}

void ImageManager::DeleteImage(string key)
{
    map<string, Image*>::iterator it;
    it = mImageDatas.find(key);

    if (it == mImageDatas.end())
    {
        return;
    }

    // �ʿ� key, value pair�� �ִ� ����
    // value�� �ش��ϴ� Image* �����͵� �޸� �����ؾ� �Ѵ�.
    (it->second)->Release();
    delete (it->second);
    (it->second) = nullptr;

    mImageDatas.erase(it);
}

Image* ImageManager::FindImage(string key)
{
    map<string, Image*>::iterator it;
    it = mImageDatas.find(key);

    if (it == mImageDatas.end())
    {
        return nullptr;
    }

    return it->second;
}
