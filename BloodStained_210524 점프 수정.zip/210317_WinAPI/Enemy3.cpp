#include "Enemy3.h"
#include "CommonFunction.h"
#include "Image.h"
#include "Camera.h"
#include "MissileManager.h"

HRESULT Enemy3::Init(int posX, int posY)
{
	enemy = ImageManager::GetSingleton()->FindImage("Enemy3");

	enemyMove = ImageManager::GetSingleton()->FindImage("Enemy3_Shoot");

	pos.x = posX;
	pos.y = posY;

	size = 50;

	enemyHp = 40;
	enemyAttack = 1;

	frameX = 0;
	frameY = 1;
	maxFrame = 5;
	updateCount = 0;

	fireCount = 0;

	moveSpeed = 150.0f;

	isAlive = true;
	isLeft = true;
	isMove = false;

	// �̻��� �Ŵ���
	missileMgr = new MissileManager();
	missileMgr->Init(this);

	return S_OK;
}

void Enemy3::Release()
{
	SAFE_RELEASE(missileMgr);
}

void Enemy3::Update()
{
	worldPos.x = pos.x;
	worldPos.y = pos.y;

	if (isAlive)
	{
		// �̻��� �߻�
		if (missileMgr)
		{
			// �Լ� ȣ�� �ֱ⸦ �ٲ㺸��.
			fireCount++;
			if (fireCount % 5 == 0)
			{
				fireCount = 0;
				missileMgr->Fire();
			}
			missileMgr->Update();
		}

		// �ִϸ��̼� ������
		updateCount++;
		if (updateCount == 20)
		{
			frameX++;
			if (frameX >= maxFrame)
			{
				frameX = 0;
			}

			updateCount = 0;
		}

		rcEnemy = GetRectToCenter(scPos.x, scPos.y, size, size);
	}

	if (enemyHp == 0)
	{
		isAlive = false;
		rcEnemy = GetRectToCenter(scPos.x - 100, scPos.y - 100, size, size);
	}

	Move();

	CameraObject::UpdatePos();
}

void Enemy3::Render(HDC hdc)
{
	if (isAlive)
	{
		if (enemy)
		{
			RenderRectToCenter(hdc, scPos.x, scPos.y, size, size);

			enemy->FrameRender(hdc, scPos.x, scPos.y, frameX, frameY, true);
		}

		if (isMove == true);
		{
			if (enemyMove)
			{
				enemyMove->FrameRender(hdc, pos.x, pos.y, frameX, frameY, true);
			}
		}

		if (missileMgr)
		{
			missileMgr->Render(hdc);
		}
	}
}

void Enemy3::Move()
{
	if (KeyManager::GetSingleton()->IsStayKeyDown(VK_SPACE))
	{
		missileMgr->Fire();
	}
}
