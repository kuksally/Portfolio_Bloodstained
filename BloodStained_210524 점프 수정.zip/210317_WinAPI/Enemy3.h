#pragma once
#include "Enemy.h"

class Enemy3 : public Enemy
{
private:
	//Image* enemyShoot;

public:
	HRESULT Init(int posX = 0, int posY = 0);
	void Release();
	void Update();
	void Render(HDC hdc);

	void Move();
};

