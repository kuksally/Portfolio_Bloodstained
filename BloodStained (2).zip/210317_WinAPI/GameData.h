#pragma once
#include "config.h"
#include "Singleton.h"

class GameData : public Singleton<GameData>
{
private:
	int playerLife;
	int playerHp;

public:
	HRESULT Init();

	inline void SetPlayerLife(int playerLife) { this->playerLife = playerLife; }
	inline int GetPlayerLife() { return this->playerLife; }

	inline void SetPlayerHp(int playerHp) { this->playerHp = playerHp; }
	inline int GetPlayerHp() { return this->playerHp; }
};