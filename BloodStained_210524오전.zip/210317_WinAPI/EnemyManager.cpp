#include "EnemyManager.h"
#include "Enemy1.h"
#include "Enemy2.h"

HRESULT EnemyManager::Init()
{
    vEnemys.resize(3);
    for (int i = 0; i < vEnemys.size(); i++)
    {
        //vEnemys[i] = new Enemy1();
        // ���� ��ǥ
        //vEnemys[i]->Init(WINSIZE_X / 2 + (WINSIZE_X / 2) + (i * 50), WINSIZE_Y - 180 - 32 + (WINSIZE_Y / 2));       
        // ���� ��ǥ
        //vEnemys[i]->Init(WINSIZE_X + (i * 50), WINSIZE_Y + 148);
      
        vEnemys[i] = new Enemy2();
        vEnemys[i]->Init(WINSIZE_X + (i * 50), WINSIZE_Y + 148);

    }

    //for (int i = 0; i < 3; i++)
    //{
    //    AddEnemy1(i, WINSIZE_X + (i * 50), WINSIZE_Y + 148);
    //}

    return S_OK;
}

void EnemyManager::Release()
{
    // �ݺ���(iterator) : STL �ڷᱸ���� �����ϴ� ������ �޸𸮸� �����ϴ� ��ü
    vector<Enemy*>::iterator it;
    for (it = vEnemys.begin(); it != vEnemys.end(); it++)
    {
        (*it)->Release();   // (*it) -> Enemy* ������Ÿ��Ȯ��
        delete (*it);
        (*it) = nullptr;
    }
}

void EnemyManager::Update()
{
    for (int i = 0; i < vEnemys.size(); i++)
    {
        vEnemys[i]->Update(); 
    }
}

void EnemyManager::Render(HDC hdc)
{
    vector<Enemy*>::iterator it;
    for (it = vEnemys.begin(); it != vEnemys.end(); it++)
    {
        (*it)->Render(hdc);
    }
}

void EnemyManager::AddEnemy1(int size, int x, int y)
{
    for (int i = 0; i < size; i++)
    {
        vEnemys.push_back(new Enemy1());
        vEnemys[vEnemys.size() - 1]->Init(x, y);
    }
}