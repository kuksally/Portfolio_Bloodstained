#include "Enemy2.h"
#include "CommonFunction.h"
#include "Image.h"
#include "Camera.h"
#include "MissileManager.h"

HRESULT Enemy2::Init(int posX, int posY)
{
	enemy = ImageManager::GetSingleton()->FindImage("Enemy2");

	enemyMove = ImageManager::GetSingleton()->FindImage("Enemy2_Move");

	pos.x = posX;
	pos.y = posY;

	size = 40;

	enemyHp = 20;
	enemyAttack = 1;

	frameX = 0;
	frameY = 1;
	maxFrame = 7;
	updateCount = 0;

	//fireCount = 0;

	moveSpeed = 150.0f;

	isAlive = true;
	isLeft = true;
	isMove = false;

	// �̻��� �Ŵ���
	missileMgr = new MissileManager();
	missileMgr->Init(this);

	return S_OK;
}

void Enemy2::Release()
{
	SAFE_RELEASE(missileMgr);
}

void Enemy2::Update()
{
	worldPos.x = pos.x;
	worldPos.y = pos.y;

	if (isAlive)
	{
		// �̻��� �߻�
		//if (missileMgr)
		//{
		//	// �Լ� ȣ�� �ֱ⸦ �ٲ㺸��.
		//	fireCount++;
		//	if (fireCount % 20 == 0)
		//	{
		//		fireCount = 0;
		//		missileMgr->Fire();
		//	}
		//	missileMgr->Update();
		//}

		// �ִϸ��̼� ������
		updateCount++;
		if (updateCount == 20)
		{
			frameX++;
			if (frameX >= maxFrame)
			{
				frameX = 0;
			}

			updateCount = 0;
		}
	}

	if (enemyHp == 0)
	{
		isAlive = false;
		rcEnemy = GetRectToCenter(-100, -100, size, size);
	}

	Move();

	rcEnemy = GetRectToCenter(scPos.x, scPos.y, size, size);

	CameraObject::UpdatePos();
}

void Enemy2::Render(HDC hdc)
{
	if (isAlive)
	{
		if (enemy)
		{
			RenderRectToCenter(hdc, scPos.x, scPos.y, size, size);

			enemy->FrameRender(hdc, scPos.x, scPos.y, frameX, frameY, true);
		}

		if (isMove == true);
		{
			if (enemyMove)
			{
				enemyMove->FrameRender(hdc, pos.x, pos.y, frameX, frameY, true);
			}
		}

		//if (missileMgr)
		//{
		//	missileMgr->Render(hdc);
		//}
	}
}

void Enemy2::Move()
{
	if (KeyManager::GetSingleton()->IsStayKeyDown('H'))
	{
		isMove = true;
		frameY = 1;
		maxFrame = 2;
		pos.x -= moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();
	}

	if (KeyManager::GetSingleton()->IsStayKeyDown('K'))
	{
		isMove = true;
		frameY = 0;
		maxFrame = 2;
		pos.x += moveSpeed * TimerManager::GetSingleton()->GetElapsedTime();
	}
}
